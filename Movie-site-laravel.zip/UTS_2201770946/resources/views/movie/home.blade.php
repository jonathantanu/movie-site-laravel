@extends('templates.base')

@section('body')


<nav class="navbar navbar-expand-lg navbar-light bg-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link text-light" href="/">Home<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Category
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="/category/drama">Drama</a>
                    <a class="dropdown-item" href="/category/kids">Kids</a>
                    <a class="dropdown-item" href="/category/tv-show">Tv Show</a>
                </div>
            </li>
        </ul>
    </nav>
    <div class="container m-3">
        <h2>Bee Flix</h2>
    </div>
    
<div class="container m-3">
    <a class="btn btn-outline-success btn-dis" href="{{ url()->previous() }}">Go Back</a>
</div>

<div class="container-fluid">
    
    <div class = "container">
        <h1 class="text-center">DRAMA</h1>
    </div>
    <div class="row">
        @foreach($movie as $mv)
            @if($mv->genres_id == 1)
            <div class="card-group">
                <div class="card m-3 " style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">{{$mv->movies_title}}</h5>
                        <img class="card-img-top img-fluid" src="{{$mv->movies_photo}}" width="300px" heigh="500px" alt="Card-Image-cap">
                        <a href="/detail/{{$mv->id}}" class="btn btn-primary btn-blue btn-toolbar mt-3">See Film</a>
                    </div>
                </div>
            </div>
            @endif
        @endforeach  
    </div>
    <div class = "container">
        <h1 class="text-center">KIDS SHOW</h1>
    </div>
    <div class="row">
        @foreach($movie as $mv)
            @if($mv->genres_id == 2)
            <div class="card-group">
                <div class="card m-3 " style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">{{$mv->movies_title}}</h5>
                        <img class="card-img-top img-fluid" src="{{$mv->movies_photo}}" width="300px" heigh="500px" alt="Card-Image-cap">
                        <a href="/detail/{{$mv->id}}" class="btn btn-primary btn-blue btn-toolbar mt-3">See Film</a>
                    </div>
                </div>
            </div>
            @endif
        @endforeach  
    </div>
    <div class = "container">
        <h1 class="text-center">TV SHOW</h1>
    </div>
    <div class="row">
        @foreach($movie as $mv)
            @if($mv->genres_id == 3)
            <div class="card-group">
                <div class="card m-3 " style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title">{{$mv->movies_title}}</h5>
                        <img class="card-img-top img-fluid" src="{{$mv->movies_photo}}" width="300px" heigh="500px" alt="Card-Image-cap">
                        <a href="/detail/{{$mv->id}}" class="btn btn-primary btn-blue btn-toolbar mt-3">See Film</a>
                    </div>
                </div>
            </div>
            @endif
        @endforeach  
    </div>
</div>

