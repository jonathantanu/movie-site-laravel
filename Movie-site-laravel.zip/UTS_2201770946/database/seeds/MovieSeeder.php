<?php

use Illuminate\Database\Seeder;

class MovieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('movies')->insert([
            ['genres_id' => 1, 'movies_title' => "The Queen's Gambit", 'movies_photo' => '/images/Drama/queen_gambit.jpg', 'movies_description' => 'Orphaned at 9, prodigious introvert Beth Harmon discovers and masters the game of chess in 1960s USA. But, child stardom comes at a price.', 'movies_rating' => '9'],
            ['genres_id' => 1, 'movies_title' => 'Barbarians', 'movies_photo' => '/images/Drama/barbarians.jpg', 'movies_description' => 'The famous battle of the Teutoburg Forest, in which Germanic warriors halted the northward advance of the Roman Empire in AD 9, is the focus of "The Barbarians."', 'movies_rating' => '7'],
            ['genres_id' => 1, 'movies_title' => 'The Haunting of Bly Manor', 'movies_photo' => '/images/Drama/haunting_bly_manor.jpg', 'movies_description' => 'After an au pair’s tragic death, Henry hires a young American nanny to care for his orphaned niece and nephew who reside at Bly Manor with the chef Owen, groundskeeper Jamie and housekeeper, Mrs. Grose.', 'movies_rating' => '8'],    
            ['genres_id' => 1, 'movies_title' => 'Undoing', 'movies_photo' => '/images/Drama/undoing.jpg', 'movies_description' => 'Life for a successful therapist in New York begins to unravel on the eve of publishing her first book.', 'movies_rating' => '8'],
            ['genres_id' => 1, 'movies_title' => 'Rebecca', 'movies_photo' => '/images/Drama/rebecca.jpg', 'movies_description' => "A young newlywed arrives at her husband's imposing family estate on a windswept English coast and finds herself battling the shadow of his first wife, Rebecca, whose legacy lives on in the house long after her death.", 'movies_rating' => '6'],
            ['genres_id' => 2, 'movies_title' => 'Phill of the Future', 'movies_photo' => '/images/KidsShow/phil_of_future.jpg', 'movies_description' => 'A family from 2121 is stuck in 2004, trying desperately to fit in.', 'movies_rating' => '7'],
            ['genres_id' => 2, 'movies_title' => 'Lizzie McGuire', 'movies_photo' => '/images/KidsShow/lizzie_mcguire.jpg', 'movies_description' => 'The daily adventures of an adolescent girl whose real thoughts and emotions are expressed by her sarcastic animated alter ego. New episodes starting November 12th 2020 on Disney+.', 'movies_rating' => '7'],
            ['genres_id' => 2, 'movies_title' => 'Captain Planet and the Planeteers', 'movies_photo' => '/images/KidsShow/captain_planet.jpg', 'movies_description' => 'A quintet of teenagers work together to encourage environmentally responsible behavior and can summon a superhero to deal with ecological disasters.', 'movies_rating' => '7'],
            ['genres_id' => 2, 'movies_title' => 'Adventures of the Gummi Bears', 'movies_photo' => '/images/KidsShow/adventure_gummi_bear.jpg', 'movies_description' => 'A group of reclusive humanoid bears and a few trusted humans explore their lost heritage and prevent their enemies from exploiting it.', 'movies_rating' => '8'],
            ['genres_id' => 2, 'movies_title' => 'Pokemon', 'movies_photo' => '/images/KidsShow/pokemon.jpg', 'movies_description' => 'Ash Ketchum, his yellow pet Pikachu, and his human friends explore a world of powerful creatures.', 'movies_rating' => '8'],
            ['genres_id' => 3, 'movies_title' => 'Breaking Bad', 'movies_photo' => '/images/TvShow/breaking_bad.jpg', 'movies_description' => "A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family's future.", 'movies_rating' => '10'],
            ['genres_id' => 3, 'movies_title' => 'Game of Thrones', 'movies_photo' => '/images/TvShow/game_throne.jpg', 'movies_description' => 'Nine noble families fight for control over the lands of Westeros, while an ancient enemy returns after being dormant for millennia.', 'movies_rating' => '9'],
            ['genres_id' => 3, 'movies_title' => 'Chernobyl', 'movies_photo' => '/images/TvShow/chernobyl.jpg', 'movies_description' => "In April 1986, an explosion at the Chernobyl nuclear power plant in the Union of Soviet Socialist Republics becomes one of the world's worst man-made catastrophes.", 'movies_rating' => '9'],
            ['genres_id' => 3, 'movies_title' => 'Band of Brothers', 'movies_photo' => '/images/TvShow/band_brothers.jpg', 'movies_description' => 'The story of Easy Company of the U.S. Army 101st Airborne Division, and their mission in World War II Europe, from Operation Overlord, through V-J Day.', 'movies_rating' => '9'],
            ['genres_id' => 3, 'movies_title' => 'Sherlock', 'movies_photo' => '/images/TvShow/sherlock.jpg', 'movies_description' => 'A modern update finds the famous sleuth and his doctor partner solving crime in 21st century London.', 'movies_rating' => '9'],
        ]);
    }
}
