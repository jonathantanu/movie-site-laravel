<?php

use Illuminate\Database\Seeder;

class EpisodeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('episodes')->insert([
            ['movies_id' => 1, 'episodes_episode' => '1', 'episodes_title' => 'The family'],
            ['movies_id' => 1, 'episodes_episode' => '2', 'episodes_title' => 'Queen Reunion'],
            ['movies_id' => 1, 'episodes_episode' => '3', 'episodes_title' => 'The Last One'],
            ['movies_id' => 1, 'episodes_episode' => '4', 'episodes_title' => 'Reincarnation'],
            ['movies_id' => 1, 'episodes_episode' => '5', 'episodes_title' => 'Scream of Pain'],
            ['movies_id' => 2, 'episodes_episode' => '1', 'episodes_title' => 'Barb One'],
            ['movies_id' => 2, 'episodes_episode' => '2', 'episodes_title' => 'Barb Two'],
            ['movies_id' => 2, 'episodes_episode' => '3', 'episodes_title' => 'Barb Three'],
            ['movies_id' => 3, 'episodes_episode' => '1', 'episodes_title' => "Billy's Manor"],
            ['movies_id' => 3, 'episodes_episode' => '2', 'episodes_title' => 'Missing Person'],
            ['movies_id' => 3, 'episodes_episode' => '3', 'episodes_title' => 'The Truth'],
            ['movies_id' => 3, 'episodes_episode' => '4', 'episodes_title' => 'what happen?'],
            ['movies_id' => 4, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 4, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 4, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 5, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 5, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 5, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 6, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 6, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 6, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 7, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 7, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 7, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 8, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 8, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 8, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 9, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 9, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 9, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 10, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 10, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 10, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 11, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 11, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 11, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 12, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 12, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 12, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 13, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 13, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 13, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 14, 'episodes_episode' => '1', 'episodes_title' => 'Chapter: One'],
            ['movies_id' => 14, 'episodes_episode' => '2', 'episodes_title' => 'Chapter: Two'],
            ['movies_id' => 14, 'episodes_episode' => '3', 'episodes_title' => 'Chapter: Three'],
            ['movies_id' => 15, 'episodes_episode' => '1', 'episodes_title' => 'The Adventure of Sherlock Holmes'],
            ['movies_id' => 15, 'episodes_episode' => '2', 'episodes_title' => 'The Memoirs of Sherlock Holmes'],
            ['movies_id' => 15, 'episodes_episode' => '3', 'episodes_title' => 'The Return of Sherlock Holme'],
            ['movies_id' => 15, 'episodes_episode' => '4', 'episodes_title' => 'His Last Bow'],
            ['movies_id' => 15, 'episodes_episode' => '5', 'episodes_title' => 'The Case-Book of Sherlock Holmes'],
            ['movies_id' => 15, 'episodes_episode' => '6', 'episodes_title' => 'Moriarty and Sherlock Holmes'],
            
        ]);
    }
}
