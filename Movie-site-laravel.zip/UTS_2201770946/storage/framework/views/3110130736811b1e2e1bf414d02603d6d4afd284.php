

<?php $__env->startSection('body'); ?>

<nav class="navbar navbar-expand-lg navbar-light bg-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link text-light" href="/">Home<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Category
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="/category/drama">Drama</a>
                    <a class="dropdown-item" href="/category/kids">Kids</a>
                    <a class="dropdown-item" href="/category/tv-show">Tv Show</a>
                </div>
            </li>
        </ul>
    </nav>
    <div class="container m-3">
        <h2>Bee Flix</h2>
    </div>
<div class="container m-3">
    <a class="btn btn-outline-success btn-dis" href="<?php echo e(url()->previous()); ?>">Go Back</a>
    <a class="btn btn-primary bg-dark" href="/">View All</a>
</div>

<div class="card m-3 p-3 bg-dark" style="width: auto;">
    <div class="card m-3 p-3 bg-light">
        <div class="container">
            <div class="row">
                <div class="col">
                    <img src="<?php echo e($data['movie']->movies_photo); ?>" alt="image">
                </div>
                <div class="col">
                    <h5 class=""><?php echo e($data['movie']->movies_title); ?></h5>
                    <h6>Rating: <?php echo e($data['movie']->movies_rating); ?></h4>
                    <p class="text-s"><?php echo e($data['movie']->movies_description); ?></p>
                    <br>
                    <?php if($data['movie']->genres_id == 1): ?>
                    <h6>Kategori: Drama</h6>
                    <?php elseif($data['movie']->genres_id==2): ?>
                    <h6>Kategori: Kids</h6>
                    <?php elseif($data['movie']->genres_id==3): ?>
                    <h6>Kategori: TV Show</h6>
                    <?php endif; ?>
                </div>
                <div class="col">
                <h5>EPISODE</h5>
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">Episode</th>
                                <th scope="col">Title</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['episode']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <tr>
                            
                                <td>episode <?php echo e($ep->episodes_episode); ?></td>
                                <td>: <?php echo e($ep->episodes_title); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="">
                        <?php echo e($data['episode']->links()); ?>

                    </div>
                    
                </div>
        </div>
            
            
        </div>
    </div>
</div>
<?php echo $__env->make('templates.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\Tugas\Web Programming\UTS Movie Site\UTS_2201770946\resources\views/movie/detail.blade.php ENDPATH**/ ?>