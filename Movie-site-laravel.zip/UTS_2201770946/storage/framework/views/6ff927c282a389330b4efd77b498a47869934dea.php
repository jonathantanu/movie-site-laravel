

<?php $__env->startSection('body'); ?>

<nav class="navbar navbar-expand-lg navbar-light bg-dark">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link text-light" href="/">Home<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Category
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="/category/drama">Drama</a>
                    <a class="dropdown-item" href="/category/kids">Kids</a>
                    <a class="dropdown-item" href="/category/tv-show">Tv Show</a>
                </div>
            </li>
        </ul>
    </nav>
    <div class="container m-3">
        <h2>Bee Flix</h2>
    </div>
<div class="container m-3">
    <a class="btn btn-outline-success btn-dis" href="<?php echo e(url()->previous()); ?>">Go Back</a>
    <a class="btn btn-primary bg-dark" href="/">View All</a>
</div>

<div class="container-fluid">
    
    <div class = "container">
        <h1 class="text-center">KIDS</h1>
    </div>
    <div class="row">
        <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-group">
                <div class="card m-3 " style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($mv->movies_title); ?></h5>
                        <img class="card-img-top img-fluid" src="<?php echo e($mv->movies_photo); ?>" width="300px" heigh="500px" alt="Card-Image-cap">
                        <a href="/detail/<?php echo e($mv->id); ?>" class="btn btn-primary btn-blue btn-toolbar mt-3">See Film</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>
</div>
<?php echo $__env->make('templates.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\Tugas\Web Programming\UTS Movie Site\UTS_2201770946\resources\views/movie/kids.blade.php ENDPATH**/ ?>