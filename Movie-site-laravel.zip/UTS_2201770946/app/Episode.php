<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Episode extends Model
{
    public function Episode(){
        return $this->belongsToMany(Movie::class);
    }
    
        protected $table= 'episodes';
}
