<?php

namespace App\Http\Controllers;
use App\Movie;
use App\Episode;
use Illuminate\Http\Request;

class MovieCOntroller extends Controller
{
    public function index(){
        $movie = Movie::all();
        return view('movie.home',compact('movie'));
    }

    public function detail($id){
        $data['movie'] = Movie::find($id)->where('id',$id)->first();
        $data['episode'] = Episode::find($id)->where('movies_id','like', "$id")->paginate(3);
        return view('movie.detail',compact('data'));
    }

    public function returnDrama(){
        $movie = Movie::all()->where('genres_id','like',1);
        return view('movie.drama', compact('movie'));
    }

    public function returnKids(){
        $movie = Movie::all()->where('genres_id','like',2);
        return view('movie.kids', compact('movie'));
    }
    
    public function returnTvShow(){
        $movie = Movie::all()->where('genres_id','like',3);
        return view('movie.tvshow', compact('movie'));
    }

}
