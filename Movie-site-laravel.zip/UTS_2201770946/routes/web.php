<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', 'MovieCOntroller@index' );
Route::get('/detail/{id}','MovieCOntroller@detail');

Route::get('/category/drama', 'MovieCOntroller@returnDrama');
Route::get('/category/kids', 'MovieCOntroller@returnKids');
Route::get('/category/tv-show', 'MovieCOntroller@returnTvShow');
